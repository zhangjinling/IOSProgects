//
//  AppDelegate.h
//  UIwebView-综合
//
//  Created by Seven on 15/5/31.
//  Copyright (c) 2015年 seven. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

